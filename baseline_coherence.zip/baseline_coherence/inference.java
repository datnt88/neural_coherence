import java.util.*;
import java.io.*;
import java.util.Arrays;

public class inference{
    //inference
    static Vector<Clique>AllClique=new Vector<Clique>();
    static Vector<Tree>AllTree=new Vector<Tree>();
    static Vector<PairDocument>AllPair=new Vector<PairDocument>();
    static int window;
    static int dimension;

    static double[][] vect;static int hidden_num;
    static double[] sen_U; static double b; static double sen_W[][]; static double []sen_b;

    static double[][]word_W;static double[][] word_V;static double[]word_b;

    static double[][]sen_begin;static double[][]sen_end;

    static double[] h0;
    static int right=0;
    
    public static void main(String[] args)throws IOException{
        String v_file="";
        String vector_file="";
        for(int i=0;i<args.length;i++){
            if(args[i].equals("-window"))
                window=Integer.parseInt(args[i+1]);
            if(args[i].equals("-dimension"))
                dimension=Integer.parseInt(args[i+1]);
            if(args[i].equals("-hidden_num"))
                hidden_num=Integer.parseInt(args[i+1]);
            if(args[i].equals("-v_file"))
                v_file=args[i+1];
            if(args[i].equals("-v_vector"))
                vector_file=args[i+1];
        }
        Cal(args[0],args[1],v_file,vector_file);
        //Cal("3737");
    }

    public static void Cal(String s1,String s2,String v_file,String vector_file)throws IOException{
        Read_Test_Data data=new Read_Test_Data(dimension);
        //ReadData data=new ReadData();
        data.ReadWordVector(v_file,vector_file);
        data.Read(window,"data1_test_tree");
        AllClique=data.AllClique;
        AllTree=data.AllTree;
        AllPair=data.AllPair;
        math my_math=new math();
        vect=my_math.CopyMatrix(data.vect);
        Initial(window);
        for(int temp=1;temp<dimension;temp++){
            int right=0;
            String File=s1+Integer.toString(temp)+s2;
            System.out.println("parameter_file_name: "+File);
            ReadParameters(File);
            update_tree();
            for(int i=0;i<AllPair.size();i++){
                double pos_score=0;
                double neg_score=0;
                PairDocument pair=AllPair.get(i);
                
                Document posdoc=pair.pos_doc;
                Document negdoc=pair.neg_doc;
                for(int j=0;j<posdoc.Doc_Clique.size();j++){
                    Clique clique=posdoc.Doc_Clique.get(j);
                    pos_score+=Math.log(Cal_Score_Clique(clique));
                    //get score for orignal document (positive, coherence)
                }
                for(int j=0;j<negdoc.Doc_Clique.size();j++){
                    Clique clique=negdoc.Doc_Clique.get(j);
                    neg_score+=Math.log(Cal_Score_Clique(clique));
                    //get score for document with permutation (negative, not coherence)
                }
                if(pos_score>neg_score){
                    right++;
                }
            }
            System.out.println("right_pair "+right+" "+"total_size "+AllPair.size());
            System.out.println("accuracy "+temp+" "+1.000*right/AllPair.size()+"\n");
        }
    }

    
    public static void update_tree(){
        //update vectors for nodes within trees
        for(int i=0;i<AllTree.size();i++){
            Tree tree=AllTree.get(i);
            tree.GetVector(0,word_W,word_b,vect);
            AllTree.set(i,tree);
        }
    }
    
    public static void Initial(int Window)throws IOException{
        //initial
        window=Window;
        sen_W=new double[hidden_num][dimension*window];sen_U=new double[hidden_num];b=0;sen_b=new double[hidden_num];

        word_W=new double[dimension][dimension*2];word_b=new double[dimension];
        sen_begin=new double[window/2][dimension];sen_end=new double[window/2][dimension];
    }

    public static void ReadParameters(String filename) throws IOException{
        //read parameters from documents
        BufferedReader in=new BufferedReader(new FileReader(filename));
        String line;
        for(line=in.readLine();line!=null;line=in.readLine()){
            if(line.equals("sen_W")){
                for(int i=0;i<hidden_num;i++){
                    line=in.readLine();
                    String []dict=line.split(" ");
                    for(int j=0;j<dimension*window;j++){
                        sen_W[i][j]=Double.parseDouble(dict[j]);
                    }
                }
            }
            if(line.equals("sen_b")){
                line=in.readLine();
                String []dict=line.split(" ");
                for(int j=0;j<hidden_num;j++)
                    sen_b[j]=Double.parseDouble(dict[j]);
            }
            if(line.equals("sen_U")){
                line=in.readLine();
                String []dict=line.split(" ");
                for(int j=0;j<hidden_num;j++)
                    sen_U[j]=Double.parseDouble(dict[j]);
            }
            if(line.equals("b")){
                line=in.readLine();
                b=Double.parseDouble(line);
            }
            if(line.equals("word_W")){
                for(int i=0;i<dimension;i++){
                    line=in.readLine();
                    String []dict=line.split(" ");
                    for(int j=0;j<dimension*2;j++)
                        word_W[i][j]=Double.parseDouble(dict[j]);
                }
            }
            if(line.equals("word_b")){
                line=in.readLine();
                String []dict=line.split(" ");
                for(int j=0;j<dimension;j++)word_b[j]=Double.parseDouble(dict[j]);
            }
            if(line.equals("sen_begin")){
                for(int i=0;i<window/2;i++){
                    line=in.readLine();
                    String []dict=line.split(" ");
                    for(int j=0;j<dimension;j++)sen_begin[i][j]=Double.parseDouble(dict[j]);
                }
            }

            if(line.equals("sen_end")){
                for(int i=0;i<window/2;i++){
                    line=in.readLine();
                    String []dict=line.split(" ");
                    for(int j=0;j<dimension;j++)sen_end[i][j]=Double.parseDouble(dict[j]);
                }
            }
            /*
            if(line.indexOf("vect")!=-1){
                int count=-1;
                for(line=in.readLine();line!=null;line=in.readLine()){
                    count++;
                    String []dict=line.split(" ");
                    for(int j=0;j<dimension;j++)vect[count][j]=Double.parseDouble(dict[j]);
                }
            }
            */
        }
    }
    public static double Cal_Score_Clique(Clique current_clique){
        //calculate score for a clique
        math my_math=new math();
        double[] join;join=new double[window*dimension];
        for(int i=0;i<window;i++){
            int sen_index=current_clique.Tree_List.get(i);
            double[]t;t=new double[dimension];
            if(sen_index<0&&sen_index>=-window/2)t=sen_begin[-1-sen_index];
            else if(sen_index<-window/2)t=sen_end[-1-window/2-sen_index];
            else {
                Tree tree=AllTree.get(sen_index);
                t=tree.AllNodes.get(0).vector;
            }
            for(int j=0;j<dimension;j++)join[dimension*i+j]=t[j];
        }
        double[] sen_hidden;sen_hidden=new double[hidden_num];
        sen_hidden=my_math.Vector_Plus(my_math.Matrix_Vector_Dot(sen_W,join),sen_b);
        sen_hidden=my_math.Vector_tanh(sen_hidden);
        double score=my_math.sigmod(my_math.dot(sen_hidden,sen_U)+b);
        return score;
    }
}
