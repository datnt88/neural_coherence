javac tree_binary.java
java tree_binary -windowsize 3 -dimension 50 -read_folder wsj_all -alpha 0.01 -term_file myWords.txt -vect_file myVecs.txt -save_file mySave -C 1.25 -hidden 100 -update_e 0 -thread 1
