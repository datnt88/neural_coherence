public class math{
    public double dot(double[]a1,double[]a2){
        //dot-multiply
        double total=0;
        for(int i=0;i<a1.length;i++)
            total+=a1[i]*a2[i];
        return total;
    }
    public double[][] vector_vector_M(double[]a1,double[]a2){
        double[][]G;G=new double[a1.length][a2.length];
        for(int i=0;i<a1.length;i++)
            for(int j=0;j<a2.length;j++)
                G[i][j]=a1[i]*a2[j];
        return G;
    }

    public double tanh(double a){
        //tanh function
        double a1=Math.exp(-a);
        double a2=Math.exp(a);
        return (a2-a1)/(a2+a1);
    }
    public double derivative_tanh(double a){
        //derivative for tanh
        return 1-Math.pow(a,2);
    }

    public double[] vector_derivative_tanh(double[]a){
        //derivative for tanh for vectors
        double[]b;b=new double[a.length];
        for(int i=0;i<a.length;i++)b[i]=derivative_tanh(a[i]);
        return b;
    }

    public double[][]Matrix_Matrix_Dot(double[][]A,double[][]B){
        if(A[0].length!=B[0].length)System.out.println("Matrix Dimensions not Constant");
        double[][]C;C=new double[A.length][B.length];
        for(int i=0;i<A.length;i++){
            for(int j=0;j<B.length;j++){
                for(int k=0;k<A[0].length;k++){
                    C[i][j]+=A[i][k]*B[j][k];
                }
            }
        }
        return C;
    }
    public double[][][]Vatrix_Matrix_Dot(double[][][]A,double[][]B){
        if(A[0][0].length!=B[0].length)System.out.println("Matrix Dimensions not Constant");
        double[][][]C;C=new double[A.length][A[0].length][B.length];
        for(int i=0;i<A.length;i++){
            for(int j=0;j<A[i].length;j++){
                for(int k=0;k<B.length;k++){
                    for(int m=0;m<A[i][j].length;m++){
                        C[i][j][k]+=A[i][j][m]*B[k][m];
                    }
                }
            }
        }
        return C;
    }


    public double sigmod(double a){
        //sigmod function
        return 1/(1+Math.exp(-a));
    }
    public double derivative_sigmod(double a){
        //derivative for sigmod
        return a*(1-a);
    }
    
    public double[] Vector_tanh(double []a1){
        double[]A;A=new double[a1.length];
        for(int i=0;i<a1.length;i++)
            A[i]=tanh(a1[i]);
        return A;
    }

    public double[] Matrix_Vector_Dot(double[][] a1,double[] a2){
        double []A;
        A=new double[a1.length];
        for(int i=0;i<a1.length;i++){
            A[i]=0;
            for(int k=0;k<a1[0].length;k++)
                A[i]+=a1[i][k]*a2[k];
        }
        return A;
    }
    public double[] Vector_Plus(double[]a1,double[]a2){
        double []c;c=new double[a1.length];
        for(int i=0;i<a1.length;i++)
            c[i]=a1[i]+a2[i];
        return c;
    }
    public double[] dot_dot(double[]a1,double[]a2){
        // .dot
        double[]c;c=new double[a1.length];
        for(int i=0;i<a1.length;i++)
            c[i]=a1[i]*a2[i];
        return c;
    }
    public double[] scalar_vector(double a1,double[]a2){
        //multiple vector a2 by scalar a1
        double[]c;c=new double[a2.length];
        for(int i=0;i<a2.length;i++)
            c[i]=a1*a2[i];
        return c;
    }
    public double[][]scalar_matrix(double a1,double[][]a2){
        //multiple matrix a2 by scalar a1
        double[][]c;c=new double[a2.length][a2[0].length];
        for(int i=0;i<a2.length;i++)
            for(int j=0;j<a2[0].length;j++)
                c[i][j]=a1*a2[i][j];
        return c;
    }
    public double AverageArray(double []a){
        //return the mean of an array
        double sum=0;
        for(int i=0;i<a.length;i++)
            sum+=a[i];
        return sum/a.length;
    }

    public double Sum(double []a){
        //return the sum of an array
        double sum=0;
        for(int i=0;i<a.length;i++)
            sum+=a[i];
        return sum;
    }
    public double[] Matrix_Line_Sum(double[][]a){
        double[]L;
        L=new double[a.length];
        for(int i=0;i<a.length;i++)
            for(int j=0;j<a[0].length;j++)
                L[i]+=a[i][j];
        return L;
    }

    public double[] CopyVector(double[]a2){
        double[]a1;
        a1=new double[a2.length];
        for(int i=0;i<a1.length;i++)
            a1[i]=a2[i];
        return a1;
    }
    public double[] CopyVector(double[]a2,int begin,int end){
        double[]a1;a1=new double[end-begin];
        for(int i=begin;i<end;i++)
            a1[i-begin]=a2[i];
        return a1;
    }
    public double[][] CopyMatrix(double[][]a2){
        double[][]a1;a1=new double[a2.length][a2[0].length];
        for(int i=0;i<a1.length;i++){
            for(int j=0;j<a1[0].length;j++)
                a1[i][j]=a2[i][j];
        }
        return a1;
    }
    public double[][]Matrix_Transpose(double[][]a2){
        double[][]a1;a1=new double[a2[0].length][a2.length];
        for(int i=0;i<a2.length;i++)
            for(int j=0;j<a2[0].length;j++)
                a1[j][i]=a2[i][j];
        return a1;
    }
    public double[][]CopyMatrix(double[][]a2,int row_begin,int row_end,int column_begin,int column_end){
        double[][]a1;a1=new double[row_end-row_begin][column_end-column_begin];
        for(int i=row_begin;i<row_end;i++)
            for(int j=column_begin;j<column_end;j++)
                a1[i-row_begin][j-column_begin]=a2[i][j];
        return a1;
    }
}
