import java.util.*;
import java.util.Vector;
import java.io.*;
import java.util.Arrays;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class tree_binary{
    static Vector<Clique>AllClique=new Vector<Clique>();
    static Vector<Tree>AllTree=new Vector<Tree>();
    static Vector<Batch>AllBatch=new Vector<Batch>();
    static int window;
    static double C;
    static double alpha;
    static boolean update_e;
    static int dimension;
    static int hidden_num;
    static int thread_num;

    static double[][] vect; static double[][]delta_vect; static double[][]Ada_vect;
    static double[] sen_U; static double b; static double sen_W[][]; static double []sen_b;
    static double[][]delta_sen_W;static double[] delta_sen_U;static double[] delta_sen_b;static double delta_b;
    static double[][]Ada_sen_W;static double[] Ada_sen_U;static double[] Ada_sen_b;static double Ada_b;

    static double[][]word_W;static double[]word_b;
    static double[][]delta_word_W;static double[] delta_word_b;
    static double[][]Ada_word_W;static double[]Ada_word_b;

    static double[][]sen_begin;static double[][]sen_end;
    static double[][]delta_sen_begin;static double[][]delta_sen_end;
    static double[][]Ada_sen_begin;static double[][]Ada_sen_end;


    static double[][][]tree_b;
    static double[][][][]tree_W;
    static double[][][][]tree_vect;
    
    public static void main(String[] args)throws Exception{
        String term_file="";
        String vect_file="";
        String parameter_file="";
        String save_file="";
        String read_folder="";
        boolean READ=false;
        for(int i=0;i<args.length;i++){
            if(args[i].equals("-windowsize"))
                window=Integer.parseInt(args[i+1]);
                //window size
            if(args[i].equals("-dimension"))
                dimension=Integer.parseInt(args[i+1]);
            if(args[i].equals("-thread"))
                thread_num=Integer.parseInt(args[i+1]);
                //thread_num for java parallel
            if(args[i].equals("-hidden"))
                hidden_num=Integer.parseInt(args[i+1]);
                //hidden_layer for neural network
            if(args[i].equals("-term_file"))
                term_file=args[i+1];
            if(args[i].equals("-vect_file"))
                vect_file=args[i+1];
            if(args[i].equals("-parameter_file")){
                parameter_file=args[i+1];
                READ=true;
            }
            if(args[i].equals("-C"))
                C=Double.parseDouble(args[i+1]);
                //regulizer 
            if(args[i].equals("-alpha"))
                alpha=Double.parseDouble(args[i+1]);
                //decent rate
            if(args[i].equals("-read_folder"))
                read_folder=args[i+1];
            if(args[i].equals("-save_file"))
                save_file=args[i+1];
            if(args[i].equals("-update_e")){
                if(args[i+1].equals("1"))update_e=true;
                else update_e=false;
                //whether update word embeddings
            }
        }
        ReadData data=new ReadData(dimension);
        data.ReadWordVector(term_file,vect_file);//read word vectors
        data.Read(window,read_folder);//read parse trees
        data.GetBatch();//minibatch
        AllClique=data.AllClique;
        AllTree=data.AllTree;
        Vector<String>A=new Vector<String>();
        HashMap<String,Integer>B=new HashMap<String,Integer>();

        AllBatch=data.AllBatch;
        System.out.println(AllBatch.size());
        vect=data.vect;
        Initial(window);
        Random(window);
        math my_math=new math();
        int begin_iter=0;
        while(true){
            begin_iter++;
            System.out.println("iteration "+begin_iter);
            for(int i=0;i<AllBatch.size();i++){
            	System.out.println(i);
                if(i%100==0)System.out.println(i);
                set_delta();//set derivative to 0
                decent(i);//gradient decent
                update();//parameter update
            }
            String filename=save_file+"/win"+Integer.toString(window)+":iter"+Integer.toString(begin_iter)+":C="+Double.toString(C)+"hidden:"+Integer.toString(hidden_num)+"dimension:"+Integer.toString(dimension)+"update_2"+String.valueOf(update_e)+".txt";
            Save(filename);//save results
        }
    }

    public static void decent(int batch_num)throws Exception{
        Batch batch=AllBatch.get(batch_num);
        update_batch(batch_num);
        tree_b=Tree_b(batch);//derivative of tree vector with respecive to word_b
        tree_W=Tree_W(batch);//derivative of tree vector with respecive to word_W

        ExecutorService executor = Executors.newFixedThreadPool(thread_num);
        //multi thread
        List<Future<MultiThread>>list=new ArrayList<Future<MultiThread>>();
        Decent my_decent=new Decent();

        for(int clique_index:batch.Clique_List){
            Clique clique=AllClique.get(clique_index);
            delta_b+=(clique.clique_h-clique.tag);//derivative with regard to sen_b;
            Callable<MultiThread>worker=new MyCallable_Hi(AllClique.get(clique_index),batch);
            Future<MultiThread>submit=executor.submit(worker);
            list.add(submit);
        }
        for (Future<MultiThread> future : list) {
            MultiThread thread=future.get();
            for(int i=0;i<hidden_num;i++){
                delta_sen_U[i]+=thread.d_U[i];
                delta_sen_b[i]+=thread.d_sen_b[i];
                for(int j=0;j<window*dimension;j++){
                    delta_sen_W[i][j]+=thread.d_sen_W[i][j];
                }
            }
            for(int i=0;i<dimension;i++){
                delta_word_b[i]+=thread.d_word_b[i];
                for(int j=0;j<2*dimension;j++)
                    delta_word_W[i][j]+=thread.d_word_W[i][j];
            }
            for(int i=0;i<window/2;i++){
                for(int j=0;j<dimension;j++){
                    delta_sen_begin[i][j]+=thread.d_sen_begin[i][j];
                    delta_sen_end[i][j]+=thread.d_sen_end[i][j];
                }
            }
        }
        executor.shutdown();
        delta_b/=batch.Clique_List.size();
        
        math my_math=new math();
        double l=(double)1/batch.Clique_List.size();

        double T=2*C*window/AllClique.size();
        delta_sen_U=my_math.scalar_vector(l,delta_sen_U);
        for(int i=0;i<hidden_num;i++)delta_sen_U[i]+=T*sen_U[i];//regulizer

        delta_sen_b=my_math.scalar_vector(l,delta_sen_b);

        delta_sen_W=my_math.scalar_matrix(l,delta_sen_W);
        for(int i=0;i<hidden_num;i++)
            for(int j=0;j<window*dimension;j++)
                delta_sen_W[i][j]+=T*sen_W[i][j];//regulizer

        delta_sen_begin=my_math.scalar_matrix(l,delta_sen_begin);
        delta_sen_end=my_math.scalar_matrix(l,delta_sen_end);
        delta_word_b=my_math.scalar_vector(l,delta_word_b);
        delta_word_W=my_math.scalar_matrix(l,delta_word_W);
        for(int i=0;i<dimension;i++)
            for(int j=0;j<2*dimension;j++)
                delta_word_W[i][j]+=T*word_W[i][j];//regulizer
    }
    public static void ReadModel(String filename) throws Exception{
        //read parameters from an existing model
        BufferedReader in=new BufferedReader(new FileReader(filename));
        String line;
        for(line=in.readLine();line!=null;line=in.readLine()){
            if(line.equals("sen_W")){
                for(int i=0;i<hidden_num;i++){
                    line=in.readLine();
                    String []dict=line.split(" ");
                    for(int j=0;j<50*window;j++)
                        sen_W[i][j]=Double.parseDouble(dict[j]);
                }
            }
            if(line.equals("sen_b1")){
                line=in.readLine();
                String []dict=line.split(" ");
                for(int j=0;j<hidden_num;j++)
                    sen_b[j]=Double.parseDouble(dict[j]);
            }
            if(line.equals("sen_U")){
                line=in.readLine();
                String []dict=line.split(" ");
                for(int j=0;j<hidden_num;j++)
                    sen_U[j]=Double.parseDouble(dict[j]);
            }
            if(line.equals("word_W")){
                for(int i=0;i<50;i++){
                    line=in.readLine();
                    String []dict=line.split(" ");
                    for(int j=0;j<100;j++)
                        word_W[i][j]=Double.parseDouble(dict[j]);
                }
            }
            if(line.equals("sen_begin")){
                for(int i=0;i<window/2;i++){
                    line=in.readLine();
                    String []dict=line.split(" ");
                    for(int j=0;j<50;j++)
                        sen_begin[i][j]=Double.parseDouble(dict[j]);
                }
            }
            if(line.equals("sen_end")){
                for(int i=0;i<window/2;i++){
                    line=in.readLine();
                    String []dict=line.split(" ");
                    for(int j=0;j<50;j++)
                        sen_end[i][j]=Double.parseDouble(dict[j]);
                }
            }
            if(line.equals("word_b")){
                line=in.readLine();
                String []dict=line.split(" ");
                for(int j=0;j<50;j++)word_b[j]=Double.parseDouble(dict[j]);
            }
            if(line.indexOf("vect")!=-1){
                int count=-1;
                for(line=in.readLine();line!=null;line=in.readLine()){
                    count++;
                    String []dict=line.split(" ");
                    for(int j=0;j<50;j++)vect[count][j]=Double.parseDouble(dict[j]);
                }
            }
        }
    }

    public static double CalBatch(Batch batch,double[] my_sen_U,double my_b,double[][]my_sen_W,double[]my_sen_b,double[][]my_word_W,double[]my_word_b,double[][]my_sen_begin,double[][]my_sen_end,double[][]my_vect){
        //calculate objective function value for a batch
        math my_math=new math();
        double total=0;
        for(int clique_num:batch.Clique_List){
            Clique clique=AllClique.get(clique_num);
            total+=CalClique_Value(clique,my_sen_U,my_b,my_sen_W,my_sen_b,my_word_W,my_word_b,my_sen_begin,my_sen_end);
        }
        total/=batch.Clique_List.size();
        return total;
    }


    public static void update(){//update parameters
        double alpha=0.01;
        for(int i=0;i<hidden_num;i++){
            Ada_sen_U[i]+=Math.pow(delta_sen_U[i],2);
            sen_U[i]-=alpha*delta_sen_U[i]/Math.sqrt(Ada_sen_U[i]);


            Ada_sen_b[i]+=Math.pow(delta_sen_b[i],2);
            sen_b[i]-=alpha*delta_sen_b[i]/Math.sqrt(Ada_sen_b[i]);

            for(int j=0;j<dimension*window;j++){
                Ada_sen_W[i][j]+=Math.pow(delta_sen_W[i][j],2);
                sen_W[i][j]-=alpha*delta_sen_W[i][j]/Math.sqrt(Ada_sen_W[i][j]);
            }
        }
        for(int i=0;i<dimension;i++){
            Ada_word_b[i]+=Math.pow(delta_word_b[i],2);
            word_b[i]-=alpha*delta_word_b[i]/Math.sqrt(Ada_word_b[i]);
            for(int j=0;j<2*dimension;j++){
                Ada_word_W[i][j]+=Math.pow(delta_word_W[i][j],2);
                word_W[i][j]-=alpha*delta_word_W[i][j]/Math.sqrt(Ada_word_W[i][j]);
            }
        }
        for(int i=0;i<window/2;i++){
            for(int j=0;j<dimension;j++){
                if(delta_sen_begin[i][j]!=0){
                    Ada_sen_begin[i][j]+=Math.pow(delta_sen_begin[i][j],2);
                    sen_begin[i][j]-=alpha*delta_sen_begin[i][j]/Math.sqrt(Ada_sen_begin[i][j]);
                }

                if(delta_sen_end[i][j]!=0){
                    Ada_sen_end[i][j]+=Math.pow(delta_sen_end[i][j],2);
                    sen_end[i][j]-=alpha*delta_sen_end[i][j]/Math.sqrt(Ada_sen_end[i][j]);
                }
            }
        }
        Ada_b+=Math.pow(delta_b,2);
        b-=alpha*delta_b/Math.sqrt(Ada_b);
    }

    public static double CalClique_Value(Clique clique,double[] my_sen_U,double my_b,double[][]my_sen_W,double[]my_sen_b,double[][]my_word_W,double[]my_word_b,double[][]my_sen_begin,double[][]my_sen_end){
        //calculate objective function value for clique
        for(int tree_index:clique.Tree_List){
            if(tree_index<0)continue;
            Tree tree=AllTree.get(tree_index);
            tree.GetVector(0,my_word_W,my_word_b,vect);
            AllTree.set(tree_index,tree);
        }
        clique.join=new double[dimension*window];
        for(int i=0;i<window;i++){
            int tree_index=clique.Tree_List.get(i);
            if(tree_index<0&&tree_index>=-window/2){
                for(int j=0;j<dimension;j++)clique.join[dimension*i+j]=my_sen_begin[0-tree_index-1][j];
                continue;
            }
            if(tree_index<-window/2){
                for(int j=0;j<dimension;j++)clique.join[dimension*i+j]=my_sen_end[-window/2-tree_index-1][j];
                continue;
            }
            Tree tree=AllTree.get(tree_index);
            for(int j=0;j<dimension;j++)clique.join[dimension*i+j]=tree.AllNodes.get(0).vector[j];
        }
        math my_math=new math();
        clique.hidden_layer=my_math.Vector_tanh(my_math.Vector_Plus(my_math.Matrix_Vector_Dot(my_sen_W,clique.join),my_sen_b));//get hidden_layer
        clique.deri_hidden_layer=my_math.vector_derivative_tanh(clique.hidden_layer);
        clique.clique_h=my_math.sigmod(my_math.dot(clique.hidden_layer,my_sen_U)+my_b);
        
        double clique_h=clique.clique_h;
        double tag=(double)(clique.tag);
        double total=(-tag*Math.log(clique_h)-(1-tag)*Math.log(1-clique_h));
        return total;
    }
    public static class Check{
        //check derivative
        public static void check_b(double value,Batch batch){
            //check derivative with respect to b
            double my_b=b;
            double e=0.0001;
            my_b+=e;
            double t1=CalBatch(batch,sen_U,my_b,sen_W,sen_b,word_W,word_b,sen_begin,sen_end,vect);
            my_b-=2*e;
            double t2=CalBatch(batch,sen_U,my_b,sen_W,sen_b,word_W,word_b,sen_begin,sen_end,vect);
            double t=(t1-t2)/(2*e);
            System.out.println(value+" "+t);
            System.out.println(t-value);
        }
        public static void check_U(double value,int i,Batch batch){
            //check derivative with respect to sen_U;
            double[]my_U;my_U=new double[sen_U.length];
            math my_math=new math();
            my_U=my_math.CopyVector(sen_U);
            double e=0.0001;
            my_U[i]+=e;
            double t1=CalBatch(batch,my_U,b,sen_W,sen_b,word_W,word_b,sen_begin,sen_end,vect);
            my_U[i]-=2*e;
            double t2=CalBatch(batch,my_U,b,sen_W,sen_b,word_W,word_b,sen_begin,sen_end,vect);
            double t=(t1-t2)/(2*e);
            System.out.println(value+" "+t);
            System.out.println(t-value);
        }
        public static void check_word_b(double value,int i,Batch batch){
            //derivative with respect to word_b
            double[]my_word_b;my_word_b=new double[word_b.length];
            math my_math=new math();
            my_word_b=my_math.CopyVector(word_b);
            double e=0.0001;
            my_word_b[i]+=e;
            double t1=CalBatch(batch,sen_U,b,sen_W,sen_b,word_W,my_word_b,sen_begin,sen_end,vect);
            my_word_b[i]-=2*e;
            double t2=CalBatch(batch,sen_U,b,sen_W,sen_b,word_W,my_word_b,sen_begin,sen_end,vect);
            double t=(t1-t2)/(2*e);
            System.out.println(value+" "+t);
            System.out.println(t-value);
        }
        public static void check_sen_b(double value,int i,Batch batch){
            //check derivative with repect to sen_b
            double[]my_sen_b;my_sen_b=new double[sen_b.length];
            math my_math=new math();
            my_sen_b=my_math.CopyVector(sen_b);
            double e=0.0001;
            my_sen_b[i]+=e;
            double t1=CalBatch(batch,sen_U,b,sen_W,my_sen_b,word_W,word_b,sen_begin,sen_end,vect);
            my_sen_b[i]-=2*e;
            double t2=CalBatch(batch,sen_U,b,sen_W,my_sen_b,word_W,word_b,sen_begin,sen_end,vect);
            double t=(t1-t2)/(2*e);
            System.out.println(value+" "+t);
            System.out.println(t-value);
        }
        public static void check_word_W(double value,int i,int j,Batch batch){
            //check derivative with respect to word_W
            double[][]my_word_W;my_word_W=new double[word_W.length][word_W[0].length];
            math my_math=new math();
            my_word_W=my_math.CopyMatrix(word_W);
            double e=0.0001;
            my_word_W[i][j]+=e;
            double t1=CalBatch(batch,sen_U,b,sen_W,sen_b,my_word_W,word_b,sen_begin,sen_end,vect);
            my_word_W[i][j]-=2*e;
            double t2=CalBatch(batch,sen_U,b,sen_W,sen_b,my_word_W,word_b,sen_begin,sen_end,vect);
            System.out.println(t1+" "+t2);
            double t=(t1-t2)/(2*e);
            System.out.println(value+" "+t);
            System.out.println(t-value);
        }
        public static void check_sen_W(double value,int i,int j,Batch batch){
            //check derivative with respect to sen_W
            double[][]my_sen_W;my_sen_W=new double[sen_W.length][sen_W[0].length];
            math my_math=new math();
            my_sen_W=my_math.CopyMatrix(sen_W);
            double e=0.0001;
            my_sen_W[i][j]+=e;
            double t1=CalBatch(batch,sen_U,b,my_sen_W,sen_b,word_W,word_b,sen_begin,sen_end,vect);
            my_sen_W[i][j]-=2*e;
            double t2=CalBatch(batch,sen_U,b,my_sen_W,sen_b,word_W,word_b,sen_begin,sen_end,vect);
            System.out.println(t1+" "+t2);
            double t=(t1-t2)/(2*e);
            System.out.println(value+" "+t);
            System.out.println(t-value);
        }
        public static void check_sen_begin(double value,int i,int j,Batch batch){
            //derivative with respect to sen_begin
            double[][]my_sen_begin;my_sen_begin=new double[sen_begin.length][sen_begin[0].length];
            math my_math=new math();
            my_sen_begin=my_math.CopyMatrix(sen_begin);
            double e=0.0001;
            my_sen_begin[i][j]+=e;
            double t1=CalBatch(batch,sen_U,b,sen_W,sen_b,word_W,word_b,my_sen_begin,sen_end,vect);
            my_sen_begin[i][j]-=2*e;
            double t2=CalBatch(batch,sen_U,b,sen_W,sen_b,word_W,word_b,my_sen_begin,sen_end,vect);
            double t=(t1-t2)/(2*e);
            System.out.println(value+" "+t);
            System.out.println(t-value);
        }
        public static void check_sen_end(double value,int i,int j,Batch batch){
            //derivative with respect to sen_end
            double[][]my_sen_end;my_sen_end=new double[sen_begin.length][sen_begin[0].length];
            math my_math=new math();
            my_sen_end=my_math.CopyMatrix(sen_end);
            double e=0.0001;
            my_sen_end[i][j]+=e;
            double t1=CalBatch(batch,sen_U,b,sen_W,sen_b,word_W,word_b,sen_begin,my_sen_end,vect);
            my_sen_end[i][j]-=2*e;
            double t2=CalBatch(batch,sen_U,b,sen_W,sen_b,word_W,word_b,sen_begin,my_sen_end,vect);
            double t=(t1-t2)/(2*e);
            System.out.println(value+" "+t);
            System.out.println(t-value);
    }
    }
    
    public static class MyCallable_Hi implements Callable<MultiThread>{
        Batch batch;
        Clique clique;
        public MyCallable_Hi(Clique clique,Batch batch){
            this.clique=clique;
            this.batch=batch;
        }
        public MultiThread call()throws Exception {
            MultiThread thread=new MultiThread(hidden_num,vect.length,window,dimension);
            Decent my_decent=new Decent();
            math my_math=new math();
            thread.d_U=my_decent.decent_d_b_U(clique);
            thread.d_sen_b=my_decent.decent_d_sen_b(clique);
            thread.d_sen_W=my_decent.decent_d_sen_W(clique,thread.d_sen_b);
            thread.d_sen_begin=my_decent.decent_d_sen_begin(clique,thread.d_sen_b);
            thread.d_sen_end=my_decent.decent_d_sen_end(clique,thread.d_sen_b);
            double[][]T;T=new double[hidden_num][window*dimension];
            for(int i=0;i<hidden_num;i++)
                for(int j=0;j<window*dimension;j++)
                    T[i][j]=sen_W[i][j]*thread.d_sen_b[i];
            thread.d_word_b=my_decent.decent_d_word_b(clique,batch,T);
            thread.d_word_W=my_decent.decent_d_word_W(clique,batch,T);
            return thread;
        }
    }
    public static double[][][]Tree_b(Batch batch)throws Exception{
        double[][][]Allword_b;
        Allword_b=new double[batch.Sen_List.size()][dimension][dimension];
        ExecutorService executor = Executors.newFixedThreadPool(thread_num);
        List<Future<double[][]>>list = new ArrayList<Future<double[][]>>();
        int beginsen=0;
        for(int sen_i=0;sen_i<batch.Sen_List.size();sen_i++){
            int sen_index=batch.Sen_List.get(sen_i);
            if(sen_index>=0){
                Tree tree=AllTree.get(sen_index);
                Callable<double[][]> worker = new MyCallable_b(tree);
                Future<double[][]> submit = executor.submit(worker);
                list.add(submit);
            }
        }
        for (Future<double[][]> future : list) {
            for(int i=0;i<dimension;i++)
                Allword_b[beginsen][i]=future.get()[i];
            beginsen++;
        }
        executor.shutdown();
        return Allword_b;
    }
    public static double[][][][] Tree_W(Batch batch)throws Exception{
        double[][][][]Allword_W;
        Allword_W=new double[batch.Sen_List.size()][dimension][dimension*2][dimension];
        ExecutorService executor = Executors.newFixedThreadPool(thread_num);
        List<Future<double[][][]>>list = new ArrayList<Future<double[][][]>>();
        int beginsen=0;
        for(int sen_i=0;sen_i<batch.Sen_List.size();sen_i++){
            int sen_index=batch.Sen_List.get(sen_i);
            if(sen_index>=0){
                Tree tree=AllTree.get(sen_index);
                Callable<double[][][]> worker = new MyCallable_W(tree);
                Future<double[][][]> submit = executor.submit(worker);
                list.add(submit);
            }
        }
        math my_math=new math();
        for (Future<double[][][]> future : list) {
            for(int i=0;i<dimension;i++)
                for(int j=0;j<2*dimension;j++)
                    Allword_W[beginsen][i][j]=future.get()[i][j];
            beginsen++;
        }
        executor.shutdown();

        return Allword_W;
    }
    static public class Decent{
        //get derivative
        public static double[] decent_b(Tree tree,int node_index,int b_index){
            //get derivative of tree (sentence) vector with respect to word_B
            Node node=tree.AllNodes.get(node_index);
            node.use=new double[dimension];
            math my_math=new math();
            if(node.isleaf){
                for(int i=0;i<dimension;i++)node.use[i]=0;
                return node.use;
            }
            else if(node.children.size()==1){
                int child=node.children.get(0);
                node.use=decent_b(tree,child,b_index);
                return node.use;
            }
            else{
                double total=0;
                int left=node.children.get(0);
                int right=node.children.get(1);
                double[] leftvect;double[] rightvect;
                leftvect=new double[dimension];
                rightvect=new double[dimension];
                leftvect=decent_b(tree,left,b_index);
                rightvect=decent_b(tree,right,b_index);
                for(int t=0;t<dimension;t++){
                    for(int i=0;i<dimension;i++)
                        node.use[t]+=word_W[t][i]*leftvect[i];
                    for(int i=0;i<dimension;i++)
                        node.use[t]+=word_W[t][dimension+i]*rightvect[i];
                }
                node.use[b_index]++;
                for(int i=0;i<dimension;i++)
                    node.use[i]*=node.deri_vector[i];
                return node.use;
            }
        }
        public static double[] decent_word_W(Tree tree,int node_index,int index1,int index2){
            //get derivative of tree(sentence) vector with respect to word_W
            Node node=tree.AllNodes.get(node_index);
            node.use=new double[dimension];
            math my_math=new math();
            if(node.isleaf){
                for(int i=0;i<dimension;i++)node.use[i]=0;
                return node.use;
            }
            else if(node.children.size()==1){
                int child=node.children.get(0);
                node.use=decent_word_W(tree,child,index1,index2);
                return node.use;
            }
            else{
                double total=0;
                int left=node.children.get(0);
                int right=node.children.get(1);
                double[] leftvect;double[] rightvect;
                leftvect=new double[dimension];
                rightvect=new double[dimension];
                leftvect=decent_word_W(tree,left,index1,index2);
                rightvect=decent_word_W(tree,right,index1,index2);
                for(int t=0;t<dimension;t++){
                    for(int i=0;i<dimension;i++)
                        node.use[t]+=word_W[t][i]*leftvect[i];
                    for(int i=0;i<dimension;i++)
                        node.use[t]+=word_W[t][dimension+i]*rightvect[i];
                }
                if(index2<dimension)node.use[index1]+=tree.AllNodes.get(left).vector[index2];
                else node.use[index1]+=tree.AllNodes.get(right).vector[index2-dimension];
                for(int i=0;i<dimension;i++)
                    node.use[i]*=node.deri_vector[i];
                return node.use;
            }
        }
        static public double[]decent_d_word_b(Clique clique,Batch batch,double[][]T){
            //get derivative of clique value with respect to word_b
            double[]for_b;for_b=new double[dimension];
            double[][]join;
            join=new double[dimension][window*dimension];
            for(int i=0;i<clique.Tree_List.size();i++){
                int sen_index=clique.Tree_List.get(i);
                if(sen_index<0)continue;
                int index=batch.Sen_List.indexOf(sen_index);
                for(int j=0;j<dimension;j++){
                    for(int k=0;k<dimension;k++){
                        join[j][dimension*i+k]=tree_b[index][j][k];
                    }
                }
            }
            math my_math=new math();
            for_b=my_math.Matrix_Line_Sum(my_math.Matrix_Matrix_Dot(join,T));
            return for_b;
        }

        static public double[][]decent_d_word_W(Clique clique,Batch batch,double[][]T){
            //get derivative of clique value with respect to word_W
            double[][]for_W;for_W=new double[dimension][2*dimension];
            double[][][]join;
            join=new double[dimension][2*dimension][window*dimension];
            for(int i=0;i<clique.Tree_List.size();i++){
                int sen_index=clique.Tree_List.get(i);
                if(sen_index<0)continue;
                int index=batch.Sen_List.indexOf(sen_index);
                for(int j=0;j<dimension;j++){
                    for(int m=0;m<2*dimension;m++){
                        for(int k=0;k<dimension;k++){
                            join[j][m][dimension*i+k]=tree_W[index][j][m][k];
                        }
                    }
                }
            }
            math my_math=new math();
            for(int i=0;i<dimension;i++)
                for_W[i]=my_math.Matrix_Line_Sum(my_math.Matrix_Matrix_Dot(join[i],T));
            return for_W;
        }

        static public double[][] decent_d_sen_end(Clique clique,double[]d_sen_b){
            //get derivative of clique value with respect to sen_end
            math my_math=new math();
            double[][]for_sen_end;for_sen_end=new double[window/2][dimension];
            for(int i=0;i<window;i++){
                int sen_num=clique.Tree_List.get(i);
                if(sen_num<-window/2){
                    int sen_end_index=-window/2-sen_num-1;
                    for_sen_end[sen_end_index]=my_math.Matrix_Vector_Dot(my_math.Matrix_Transpose(my_math.CopyMatrix(sen_W,0,hidden_num,dimension*i,dimension*(i+1))),d_sen_b);
                }
            }
            return for_sen_end;
        }
        static public double[][] decent_d_sen_begin(Clique clique,double[]d_sen_b){
            //get derivative of clique value with respect to sen_begin
            math my_math=new math();
            double[][]for_sen_begin;for_sen_begin=new double[window/2][dimension];
            for(int i=0;i<window;i++){
                int sen_num=clique.Tree_List.get(i);
                if(sen_num<0&&sen_num>=-window/2){
                    int sen_begin_index=-1-sen_num;
                    for_sen_begin[sen_begin_index]=my_math.Matrix_Vector_Dot(my_math.Matrix_Transpose(my_math.CopyMatrix(sen_W,0,hidden_num,dimension*i,dimension*(i+1))),d_sen_b);
                }
            }
            return for_sen_begin;
        }
        static public double[][] decent_d_sen_W(Clique clique,double[]d_sen_b){
            //get derivative of clique value with respect to sen_W
            math my_math=new math();
            double[][]for_sen_W;for_sen_W=new double[hidden_num][window*dimension];
            for_sen_W=my_math.vector_vector_M(d_sen_b,clique.join);
            return for_sen_W;
        }
        static public double[] decent_d_b_U(Clique clique){
            //get derivative of clique value with respect to sen_U
            double[]for_U;for_U=new double[hidden_num];
            double t=clique.clique_h-clique.tag;
            math my_math=new math();
            for_U=my_math.scalar_vector(t,clique.hidden_layer);
            return for_U;
        }
        static public double[] decent_d_sen_b(Clique clique){
            //get derivative of clique value with respect to sen_b
            math my_math=new math();
            double[]for_sen_b;for_sen_b=new double[hidden_num];
            double t=clique.clique_h-clique.tag;
            for_sen_b=my_math.scalar_vector(t,my_math.dot_dot(sen_U,clique.deri_hidden_layer));
            return for_sen_b;
        }
    }

    public static void update_batch(int batch_num){
        //update all node vectors within trees in the batch
        Batch batch=AllBatch.get(batch_num);
        for(int tree_index:batch.Sen_List){
            Tree tree=AllTree.get(tree_index);
            tree.GetVector(0,word_W,word_b,vect);
            AllTree.set(tree_index,tree);
        }
        for(int clique_index:batch.Clique_List){
            Clique clique=AllClique.get(clique_index);
            AllClique.set(clique_index,CalClique(clique));
        }
    }
    /*
    public static void update_batch(int batch_num,double[]my_U,double my_b,double[]my_sen_b,double[][]my_sen_W,double[]my_word_b,double[][]my_word_W,double[][]my_sen_begin,double[][]my_sen_end,double[][]my_vect){
        Batch batch=AllBatch.get(batch_num);
        for(int tree_index:batch.Sen_List){
            Tree tree=AllTree.get(tree_index);
            tree.GetVector(0,my_word_W,my_word_b,my_vect);
            AllTree.set(tree_index,tree);
        }
        for(int clique_index:batch.Clique_List){
            Clique clique=AllClique.get(clique_index);
            AllClique.set(clique_index,CalClique(clique,my_U,my_b,my_sen_b,my_sen_W,my_sen_begin,my_sen_end));
        }
    }
    */
    public static void Initial(int Window)throws IOException{
        //Initial
        window=Window;
        sen_W=new double[hidden_num][dimension*window];sen_U=new double[hidden_num];b=0;sen_b=new double[hidden_num];
        delta_sen_W=new double[hidden_num][dimension*window];delta_sen_U=new double[hidden_num];delta_b=0;
        Ada_sen_W=new double[hidden_num][dimension*window];Ada_sen_U=new double[hidden_num];
        Ada_b=0;Ada_sen_b=new double[hidden_num];
        delta_sen_b=new double[hidden_num];

        word_W=new double[dimension][dimension*2];word_b=new double[dimension];
        delta_word_W=new double[dimension][dimension*2];delta_word_b=new double[dimension];
        Ada_word_W=new double[dimension][dimension*2];Ada_word_b=new double[dimension];

        sen_begin=new double[window/2][dimension];delta_sen_begin=new double[window/2][dimension];Ada_sen_begin=new double[window/2][dimension];
        sen_end=new double[window/2][dimension];delta_sen_end=new double[window/2][dimension];Ada_sen_end=new double[window/2][dimension];

    }
    public static Clique CalClique(Clique clique){
        //Calculate the value for a clique
        clique.join=new double[dimension*window];
        for(int i=0;i<window;i++){
            int tree_index=clique.Tree_List.get(i);
            if(tree_index<0&&tree_index>=-window/2){
                for(int j=0;j<dimension;j++)clique.join[dimension*i+j]=sen_begin[0-tree_index-1][j];
                continue;
            }
            if(tree_index<-window/2){
                for(int j=0;j<dimension;j++)clique.join[dimension*i+j]=sen_end[-window/2-tree_index-1][j];
                continue;

            }
            Tree tree=AllTree.get(tree_index);
            for(int j=0;j<dimension;j++)clique.join[dimension*i+j]=tree.AllNodes.get(0).vector[j];
        }
        math my_math=new math();
        clique.hidden_layer=my_math.Vector_tanh(my_math.Vector_Plus(my_math.Matrix_Vector_Dot(sen_W,clique.join),sen_b));
        clique.deri_hidden_layer=my_math.vector_derivative_tanh(clique.hidden_layer);
        clique.clique_h=my_math.sigmod(my_math.dot(clique.hidden_layer,sen_U)+b);
        return clique;
    }
    public static void set_delta(){
        //set derivative to 0
        delta_b=0;
        for(int i=0;i<hidden_num;i++){
            delta_sen_b[i]=0;delta_sen_U[i]=0;
            for(int j=0;j<dimension*window;j++)delta_sen_W[i][j]=0;
        }
        for(int i=0;i<dimension;i++){
            for(int j=0;j<2*dimension;j++){
                delta_word_W[i][j]=0;
            }
        }
        for(int i=0;i<window/2;i++){
            for(int j=0;j<dimension;j++){
                delta_sen_begin[i][j]=0;
                delta_sen_end[i][j]=0;
            }
        }
    }
    public static void Random(int Window)throws IOException{
        //random initialization
        double epso=Math.sqrt(6)/(Math.sqrt(window*dimension+hidden_num));
        Random r = new Random();
        for(int i=0;i<hidden_num;i++){
            sen_U[i]=r.nextDouble()*2*epso-epso;
            //sen_b1[i]=r.nextDouble()*2*epso-epso;
            //sen_b2=r.nextDouble()*2*epso-epso;
            for(int j=0;j<dimension*window;j++)
                sen_W[i][j]=r.nextDouble()*2*epso-epso;
        }

        //epso=Math.sqrt(6)/(Math.sqrt(100));
        epso=0.25;
        for(int i=0;i<dimension;i++){
            //word_b[i]=r.nextDouble()*2*epso-epso;
            //sen_begin[i]=r.nextDouble()*2*epso-epso;
            //sen_end[i]=r.nextDouble()*2*epso-epso;
            for(int j=0;j<dimension*2;j++){
                word_W[i][j]=r.nextDouble()*2*epso-epso;
            }
        }
    }
    public static void Save(String filename)throws IOException{
        //save parameters
        FileWriter fw=new FileWriter(filename);
        fw.write("sen_W\n");
        for(int i=0;i<hidden_num;i++){
            for(int j=0;j<dimension*window;j++){
                fw.write(sen_W[i][j]+" ");
            }
            fw.write("\n");
        }

        fw.write("sen_b\n");
        for(int i=0;i<hidden_num;i++)
            fw.write(sen_b[i]+" ");
        fw.write("\n");

        fw.write("sen_U\n");
        for(int i=0;i<hidden_num;i++)
            fw.write(sen_U[i]+" ");
        fw.write("\n");

        fw.write("b\n");
        fw.write(b+"\n");

        fw.write("word_W\n");
        for(int i=0;i<dimension;i++){
            for(int j=0;j<2*dimension;j++)
                fw.write(word_W[i][j]+" ");
            fw.write("\n");
        }


        fw.write("word_b\n");
        for(int i=0;i<dimension;i++)
            fw.write(word_b[i]+" ");
        fw.write("\n");
    
        fw.write("sen_begin\n");
        for(int i=0;i<window/2;i++){
            for(int j=0;j<dimension;j++){
                fw.write(sen_begin[i][j]+" ");
            }
            fw.write("\n");
        }

        fw.write("sen_end\n");
        for(int i=0;i<window/2;i++){
            for(int j=0;j<dimension;j++)
                fw.write(sen_end[i][j]+" ");
            fw.write("\n");
        }

        /*
        fw.write("vect\n");
        for(int i=0;i<vect.length;i++){
            for(int j=0;j<vect[i].length;j++)
                fw.write(vect[i][j]+" ");
            fw.write("\n");
        }
        */
        fw.close();
    }
    public static class MyCallable_W implements Callable<double[][][]>{
        Tree tree;
        public MyCallable_W(Tree old_tree){
            this.tree=old_tree;
        }
        public double[][][] call()throws Exception {
            double[][][]L;L=new double[dimension][dimension*2][dimension];
            Decent my_decent=new Decent();
            for(int i=0;i<dimension;i++)
                for(int j=0;j<2*dimension;j++){
                    L[i][j]=my_decent.decent_word_W(tree,0,i,j);
                }
            return L;
        }
    }
    public static class MyCallable_b implements Callable<double[][]>{
        Tree tree;
        public MyCallable_b(Tree old_tree){
            this.tree=old_tree;
        }
        public double[][] call()throws Exception {
            Decent my_decent=new Decent();
            double[][]L;L=new double[dimension][dimension];
            for(int i=0;i<dimension;i++)
                L[i]=my_decent.decent_b(tree,0,i);
            return L;
        }
    }
}

class MultiThread{
    double[]d_U;
    double[]d_sen_b;
    double[][]d_sen_W;
    double[][]d_word_W;
    double[]d_word_b;
    double[][]d_sen_begin;
    double[][]d_sen_end;
    MultiThread(int hidden_num,int word_num,int window,int dimension){
        d_U=new double[hidden_num];
        d_sen_b=new double[hidden_num];
        d_word_b=new double[dimension];
        d_word_W=new double[dimension][dimension*2];
        d_sen_W=new double[hidden_num][window*dimension];
        d_sen_begin=new double[window-1][dimension];
        d_sen_end=new double[window-1][dimension];
    }
}


