import java.util.*;
import java.io.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;


class Clique{
    int tag;
    //tag=1 original window of text, positive example
    //tag=0 window of text with permutation, negative example
    Vector<Integer>Tree_List=new Vector<Integer>();
    //a sequence of sentences (trees) within the clique
    Vector<Integer>Word_List=new Vector<Integer>();
    double[]join;
    double[]hidden_layer;
    double[]deri_hidden_layer;
    double clique_h;
}


class Batch{
    //mini batch
    Vector<Integer>Clique_List=new Vector<Integer>();
    Vector<Integer>Sen_List=new Vector<Integer>();
    Vector<Integer>Word_List=new Vector<Integer>();
}

public class ReadData{

    static HashMap<String,Integer>WordToNum=new HashMap<String,Integer>();
    static HashMap<Integer,String>NumToWord=new HashMap<Integer,String>();
    static HashMap<String,Integer>ParseToNum=new HashMap<String,Integer>();
    static HashMap<Integer,String>NumToParse=new HashMap<Integer,String>();
    static double[][] vect;
    static HashMap<String,double[]>G=new HashMap<String,double[]>();
    static Vector<Clique>AllClique=new Vector<Clique>();
    static Vector<Tree>AllTree=new Vector<Tree>();
    static Vector<Batch>AllBatch=new Vector<Batch>();
    static int window;
    static int dimension;

    ReadData(int dimension){
        this.dimension=dimension;
    }

    public void GetBatch(){
        //minibatch
        int clique_num=128;
        int Total=AllClique.size()/clique_num+1;
        for(int i=0;i<Total;i++){
            Batch batch=new Batch();
            int begin=clique_num*i;
            int end;
            if(i!=Total-1) end=clique_num*(i+1);
            else end=AllClique.size();
            for(int j=begin;j<end;j++){
                Clique clique=AllClique.get(j);
                batch.Clique_List.addElement(j);
                for(int k=0;k<clique.Tree_List.size();k++){
                    int index=clique.Tree_List.get(k);
                    if(index<0)continue;
                    if(batch.Sen_List.indexOf(index)==-1)
                        batch.Sen_List.addElement(index);
                }
            }
            for(int sen_index:batch.Sen_List){
                if(sen_index<0)continue;
                for(int word_index:AllTree.get(sen_index).Word_List){
                    if(batch.Word_List.indexOf(word_index)==-1)
                        batch.Word_List.addElement(word_index);
                }
            }
            AllBatch.addElement(batch);
        }
    }

    public static void ClassifyGetClique(Vector<Integer>Sen_List)throws IOException{
        //obtain clique from the original documents
        int half_window=window/2;
        //System.out.println(window);
        int length=0;
        Tree tree;
        //System.out.println(Sen_List.size());
        //System.out.println(Sen_List);
        int len_x = Sen_List.size();
        //if(len_x >= 6){
        //	half_window = 2;
        //}
        
        
        
        for(int i=0;i<Sen_List.size();i++){
            for(int j=0;j<Sen_List.size();j++){
                Clique clique=new Clique();
                if(i==j)clique.tag=1;//orignal text, positive example
                else clique.tag=0; //random replacement, negative example
                int begin;
                if(i-half_window<0){
                    begin=0;
                    for(int k=0;k<half_window-i;k++){
                        clique.Tree_List.addElement(k+i-half_window);
                    }
                }
                else begin=i-half_window;
                for(int k=begin;k<i;k++){
                    clique.Tree_List.addElement(Sen_List.get(k));
                }
                clique.Tree_List.addElement(Sen_List.get(j));
                int end;
                if(i+half_window<Sen_List.size()){
                    end=i+half_window;
                }
                else end=Sen_List.size()-1;
                for(int k=i+1;k<end+1;k++){
                    clique.Tree_List.addElement(Sen_List.get(k));
                }
                if(i+half_window>Sen_List.size()-1){
                    for(int k=0;k<i+half_window-Sen_List.size()+1;k++){
                        clique.Tree_List.addElement(-1-half_window-k);
                    }
                }
                
                
                for(int sen_index:clique.Tree_List){
                    if(sen_index<0)continue;
                    for(int word_index:AllTree.get(sen_index).Word_List){
                        if(clique.Word_List.indexOf(word_index)==-1){
                            clique.Word_List.addElement(word_index);
                        }
                    }
                }
                //System.out.println(clique.Tree_List);
                AllClique.addElement(clique);
                //System.out.println(AllClique.size());
            }
        }
    }

    
    public static void Read(int Window,String folder_name) throws IOException{
        //read document
        window=Window;
        math My_math=new math();
        File folder=new File(folder_name);
        File[] listofFiles=folder.listFiles();
        int num=0;
        for(int i=0;i<listofFiles.length;i++){
            String filename=folder_name+"/"+listofFiles[i].getName();
            Vector<Integer>NowAllSen=new Vector<Integer>();
            BufferedReader in=new BufferedReader(new FileReader(filename));
            System.out.println(filename);
            for(String line=in.readLine();line!=null;line=in.readLine()){
            	//System.out.println(line);
                Tree tree=new Tree(dimension);
                tree.ReadTree(line,WordToNum);//read a parse tree
                tree.TwoChild();//transform to binary tree
                tree.GetOffSprint(0);
                NowAllSen.addElement(AllTree.size());
                AllTree.addElement(tree);
            }
            ClassifyGetClique(NowAllSen);//get cliques
        }
    }

    public static void ReadWordVector(String word_file,String vector_file)throws IOException {
        //Read word embeddings from Senna
        System.out.println(word_file+" "+vector_file);
        BufferedReader in1=new BufferedReader(new FileReader(word_file));
        int num_line=0;
        String line1,line2;
        for(line1=in1.readLine();line1!=null;line1=in1.readLine()){
            num_line++;
        }
        vect=new double[num_line][dimension];
        in1=new BufferedReader(new FileReader(word_file));

        BufferedReader in2=new BufferedReader(new FileReader(vector_file));
      
        int i=-1;
        for(line1=in1.readLine();line1!=null;line1=in1.readLine()){
            i++;
            line2=in2.readLine();
            WordToNum.put(line1,i);
            NumToWord.put(i,line1);
            String[] bits=line2.split("\\s+");
            for(int pos=0;pos<dimension;pos++)
                vect[i][pos]=Double.parseDouble(bits[pos]);

        }
    }
}
