import java.util.*;
import java.io.*;
import java.util.Arrays;

class Node{
    String word;
    int word_index=-1;
    String Parse;
    int Parse_index;
    boolean isleaf=false;
    Vector<Integer>children=new Vector<Integer>();
    Vector<Integer>OffspringLeaves=new Vector<Integer>();
    int parent=-1;
    int left_sibling=-1;
    int right_sibling=-1;
    int index;
    int dimension;
    double[]vector;
    double[]deri_vector;
    double[]use;
    Node(int dimension){
        this.dimension=dimension;
    }
}

public class Tree{
    int root;
    int tag;
    Vector<Node>AllNodes=new Vector<Node>();
    Vector<Integer>AllLeaves=new Vector<Integer>();
    Vector<Integer>Word_List=new Vector<Integer>();
    int dimension;
    Tree(int dimension){
        this.dimension=dimension;
    }

    public Vector<Integer> GetOffSprint(int Num){
        //Get offspring for a specific node
        Node node=AllNodes.get(Num);
        if(node.isleaf){
            node.OffspringLeaves.addElement(node.word_index);
            return node.OffspringLeaves;
        }
        if(node.children.size()==1){
            int child=node.children.get(0);
            Vector<Integer>A=GetOffSprint(child);
            for(int i=0;i<A.size();i++)node.OffspringLeaves.addElement(A.get(i));
            return node.OffspringLeaves;
        }
        else{
            int first_child=node.children.get(0);
            int second_child=node.children.get(1);
            Vector<Integer>first_list=GetOffSprint(first_child);
            Vector<Integer>second_list=GetOffSprint(second_child);
            for(int i=0;i<first_list.size();i++){
                int index=first_list.get(i);
                if(node.OffspringLeaves.indexOf(index)==-1)node.OffspringLeaves.addElement(index);
            }
            for(int i=0;i<second_list.size();i++){
                int index=second_list.get(i);
                if(node.OffspringLeaves.indexOf(index)==-1)node.OffspringLeaves.addElement(index);
            }
            return node.OffspringLeaves;
        }
    }

    public void print(){
        for(int i=0;i<AllNodes.size();i++){
            Node node=AllNodes.get(i);
            System.out.println(i+" "+node.parent+" "+node.children+" "+node.word+" "+node.isleaf+" "+node.word_index+" "+node.OffspringLeaves);
        }
    }

    public double[] GetVector(int Num,double[][]W,double[]b,double[][]vect){
        //get vector representation for an internal node
        math My_math=new math();
        Node node=AllNodes.get(Num);
        node.deri_vector=new double[dimension];
        if(node.isleaf){
            node.vector=My_math.CopyVector(vect[node.word_index]);
            node.deri_vector=My_math.vector_derivative_tanh(node.vector);
            AllNodes.set(Num,node);
            return node.vector;
        }
        if(node.children.size()==1){
            int child=node.children.get(0);
            Node child_node=AllNodes.get(child);
            node.vector=GetVector(child,W,b,vect);
            node.deri_vector=My_math.vector_derivative_tanh(node.vector);
            AllNodes.set(Num,node);
            return node.vector;
        }
        else{
            double[] first_score;first_score=new double[dimension];
            double[] second_score;second_score=new double[dimension];
            int first_child=node.children.get(0);
            int second_child=node.children.get(1);
            first_score=GetVector(first_child,W,b,vect);
            second_score=GetVector(second_child,W,b,vect);
            double[]iter; iter=new double[dimension*2];
            for(int j=0;j<dimension;j++)iter[j]=first_score[j];
            for(int j=0;j<dimension;j++)iter[dimension+j]=second_score[j];
            double[]t;t=new double[dimension];
            node.vector=My_math.Vector_tanh(My_math.Vector_Plus(My_math.Matrix_Vector_Dot(W,iter),b));
            node.deri_vector=My_math.vector_derivative_tanh(node.vector);
            AllNodes.set(Num,node);
            return node.vector;
        }
    }

    public void TwoChild(){
        //tranform to binary tree
        int Num=AllNodes.size();
        for(int i=0;i<Num;i++){
            Node node=AllNodes.get(i);
            if(node.children.size()>2){
                int left=node.children.get(0);
                int now_left=-1;
                int now_right=node.children.get(node.children.size()-1);
                for(int j=1;j<node.children.size()-1;j++){
                    int right=node.children.get(j);
                    Node new_node=new Node(dimension);
                    new_node.vector=new double[dimension];
                    new_node.use=new double[dimension];
                    new_node.children.addElement(left);
                    new_node.children.addElement(right);
                    int parent=-1;
                    if(j==node.children.size()-2)parent=i;
                    else parent=AllNodes.size()-1;
                    new_node.parent=parent;
                    Node leftnode=AllNodes.get(left);
                    Node rightnode=AllNodes.get(right);
                    AllNodes.addElement(new_node);
                    leftnode.parent=AllNodes.size()-1;
                    rightnode.parent=AllNodes.size()-1;
                    AllNodes.set(left,leftnode);
                    AllNodes.set(right,rightnode);
                    left=AllNodes.size()-1;
                    if(j==node.children.size()-2){
                        now_left=left;
                    }
                }
                node.children=new Vector<Integer>();
                node.children.addElement(now_left);
                node.children.addElement(now_right);
                AllNodes.set(i,node);
            }
        }
    }


    public void ReadTree(String text,HashMap<String,Integer>WordToNum){
        //Read a parse tree
        int i=0;
        math My_math=new math();
        Stack<Integer>stack =new Stack<Integer>();
        while(i<text.length()){
            if(text.charAt(i)=='('){
                String value="";
                i++;
                while(text.charAt(i)!='('&&text.charAt(i)!=')'){
                    value+=text.charAt(i);i++;
                }
                
                value=value.trim();
                Node node=new Node(dimension);
                node.index=AllNodes.size();
                node.Parse=value;
                if(!stack.isEmpty()){
                    Node top_node=AllNodes.get(stack.peek());
                    top_node.children.addElement(node.index);
                    node.parent=top_node.index;
                    node.vector=new double[dimension];
                    AllNodes.set(top_node.index,top_node);
                }
                AllNodes.addElement(node);
                stack.push(node.index);
            }
            else if(text.charAt(i)==')'){
                Node top_node=AllNodes.get(stack.peek());
                String Value=top_node.Parse;
                if(Value.indexOf(" ")!=-1){
                    int cut_num=Value.indexOf(" ");
                    
                    String first=Value.substring(0,cut_num);
                    String second=Value.substring(cut_num+1);
                    //System.out.println(second);
                    top_node.Parse=first;
                    
                    top_node.word_index=WordToNum.get(second.toLowerCase());
                    top_node.isleaf=true;
                    AllLeaves.addElement(top_node.index);
                    AllNodes.set(top_node.index,top_node);
                    if(Word_List.indexOf(top_node.word_index)==-1)
                        Word_List.addElement(top_node.word_index);
                }
                stack.pop();
                i++;
            }
            else if(text.charAt(i)==' ')i++;
        }
        //System.out.println(WordToNum);
    }
}



