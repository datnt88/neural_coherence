javac inference.java
java inference save1/win3:iter :C=1.25hidden:100dimension:50update_2false.txt -hidden_num 100 -dimension 50 -window 3 -v_file data1_v.txt -v_vector data1_wordvector.txt
