import java.util.*;
import java.io.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

class Document{
    Vector<Clique>Doc_Clique=new Vector<Clique>();
}

class PairDocument{
    //document pair
    String filename;
    Document pos_doc;//orignial document (positive, coherence)
    Document neg_doc;//document with permutation (negative, not coherent)
}
public class Read_Test_Data{
    static Vector<Document>AllDocument=new Vector<Document>();
    static Vector<PairDocument>AllPair=new Vector<PairDocument>();
    static Vector<Clique>AllClique=new Vector<Clique>();
    static Vector<Tree>AllTree=new Vector<Tree>();
    static HashMap<String,Integer>WordToNum=new HashMap<String,Integer>();
    static HashMap<Integer,String>NumToWord=new HashMap<Integer,String>();
    static double[][]vect;
    static int window;
    static int dimension;
    Read_Test_Data(int dimension){
        this.dimension=dimension;
    }

    public static void Read(int Window,String folder_name) throws IOException{
        window=Window;
        File folder=new File(folder_name);
        File[] listofFiles=folder.listFiles();
        HashMap<String,Vector<String>>LIST=new HashMap<String,Vector<String>>();
        for(int i=0;i<listofFiles.length;i++){
            String line=listofFiles[i].getName();
            int index=line.indexOf(".perm");
            index=line.indexOf("-",index+1);
            String cut=line.substring(0,index+1);
            if(!LIST.containsKey(cut)){
                Vector<String> AI=new Vector<String>();
                AI.addElement(line);
                LIST.put(cut,AI);
            }
            else{
                Vector<String>AI=LIST.get(cut);
                AI.addElement(line);
                LIST.put(cut,AI);
            }
        }
        Iterator iterator=LIST.keySet().iterator();
        while(iterator.hasNext()){
            String S=String.valueOf(iterator.next());
            ReadDocument(folder_name,S,LIST.get(S));
        }
    }
    public static void ReadDocument(String folder_name,String filename,Vector<String>T)throws IOException{//read document
        Vector<Document>Doc=new Vector<Document>();
        Document pos_document=new Document();
        int half_window=window/2;
        math My_math=new math();
        for(int i=0;i<T.size();i++){
            String filename1=folder_name+"/"+T.get(i);
            File f=new File(filename1);
            Vector<Integer>NowAllSen=new Vector<Integer>();
            BufferedReader in=new BufferedReader(new FileReader(filename1));
            for(String line=in.readLine();line!=null;line=in.readLine()){
                Tree tree=new Tree(dimension);
                tree.ReadTree(line,WordToNum);//read parse tree
                tree.TwoChild();//transform to binary tree
                tree.GetOffSprint(0);
                NowAllSen.addElement(AllTree.size());
                AllTree.addElement(tree);
            }

            if(filename1.indexOf("perm-0")==-1){//orignal document. positive
                Document document=new Document();
                for(int j=0;j<NowAllSen.size();j++){
                    Clique clique=new Clique();
                    int begin;
                    if(j-half_window<0){
                        begin=0;
                        for(int k=0;k<half_window-j;k++){
                            clique.Tree_List.addElement(-1);
                        }
                    }
                    else begin=j-half_window;
                    int end;
                    if(j+half_window<NowAllSen.size()){
                        end=j+half_window;
                    }
                    else end=NowAllSen.size()-1;
                    for(int k=begin;k<end+1;k++)
                        clique.Tree_List.addElement(NowAllSen.get(k));
                    if(j+half_window>NowAllSen.size()-1){
                        for(int k=0;k<j+half_window-NowAllSen.size()+1;k++){
                            clique.Tree_List.addElement(-2);
                        }
                    }
                    document.Doc_Clique.addElement(clique);
                }
                Doc.addElement(document);
            }
            else{
                for(int j=0;j<NowAllSen.size();j++){
                    Clique clique=new Clique();
                    int begin;
                    if(j-half_window<0){
                        begin=0;
                        for(int k=0;k<half_window-j;k++){
                            clique.Tree_List.addElement(-1);
                        }
                    }
                    else begin=j-half_window;
                    int end;
                    if(j+half_window<NowAllSen.size()){
                        end=j+half_window;
                    }
                    else end=NowAllSen.size()-1;
                    for(int k=begin;k<end+1;k++)
                        clique.Tree_List.addElement(NowAllSen.get(k));
                    if(j+half_window>NowAllSen.size()-1){
                        for(int k=0;k<j+half_window-NowAllSen.size()+1;k++){
                            clique.Tree_List.addElement(-2);
                        }
                    }
                    pos_document.Doc_Clique.addElement(clique);
                }
            }
        }
        for(int i=0;i<Doc.size();i++){
            PairDocument pair=new PairDocument();
            pair.filename=filename;
            pair.pos_doc=pos_document;
            pair.neg_doc=Doc.get(i);
            AllPair.addElement(pair);
        }
    }

    public static void ReadWordVector(String word_file,String vector_file)throws IOException {

        BufferedReader in1=new BufferedReader(new FileReader(word_file));
        int num_line=0;
        String line1,line2;
        for(line1=in1.readLine();line1!=null;line1=in1.readLine()){
            num_line++;
        }
        vect=new double[num_line][dimension];
        in1=new BufferedReader(new FileReader(word_file));

        BufferedReader in2=new BufferedReader(new FileReader(vector_file));
      
        int i=-1;
        for(line1=in1.readLine();line1!=null;line1=in1.readLine()){
            i++;
            line2=in2.readLine();
            WordToNum.put(line1,i);
            NumToWord.put(i,line1);
            String[] bits=line2.split("\\s+");
            for(int pos=0;pos<dimension;pos++)
                vect[i][pos]=Double.parseDouble(bits[pos]);

        }
    }

}
