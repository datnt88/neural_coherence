javac tree_binary.java
java tree_binary -windowsize 3 -dimension 50 -read_folder data1_train_tree -alpha 0.01 -term_file data1_v.txt -vect_file data1_wordvector.txt -save_file save -C 1.25 -hidden 100 -update_e 0 -thread 1
